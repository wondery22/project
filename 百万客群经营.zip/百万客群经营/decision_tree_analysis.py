# -*- coding: utf-8 -*-
"""
决策树分析 - 预测客户未来3个月资产是否能提升至100万+
使用决策树模型进行分类预测，并生成文本和图形可视化
"""

import pandas as pd
import numpy as np
from sklearn.tree import DecisionTreeClassifier, export_text, plot_tree
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report, confusion_matrix, accuracy_score
from sklearn.preprocessing import LabelEncoder
import matplotlib.pyplot as plt
import matplotlib
import seaborn as sns
import warnings
import os

# 设置中文字体和编码
matplotlib.rcParams['font.sans-serif'] = ['SimHei', 'Microsoft YaHei']
matplotlib.rcParams['axes.unicode_minus'] = False
plt.rcParams['font.size'] = 10

warnings.filterwarnings('ignore')

class DecisionTreeAnalysis:
    def __init__(self):
        """初始化决策树分析类"""
        self.customer_base = None
        self.customer_behavior = None
        self.merged_data = None
        self.features = None
        self.target = None
        self.X_train = None
        self.X_test = None
        self.y_train = None
        self.y_test = None
        self.dt_model = None
        self.feature_names = None
        
        # 创建输出目录
        if not os.path.exists('outputs'):
            os.makedirs('outputs')
    
    def load_data(self):
        """加载数据文件"""
        print("百万客群经营 - 决策树预测分析")
        print("=" * 60)
        print("正在加载数据文件...")
        
        try:
            # 加载客户基础信息
            self.customer_base = pd.read_csv('customer_base.csv', encoding='utf-8')
            print(f"客户基础信息表: {self.customer_base.shape}")
            
            # 加载客户行为资产数据
            self.customer_behavior = pd.read_csv('customer_behavior_assets.csv', encoding='utf-8')
            print(f"客户行为资产表: {self.customer_behavior.shape}")
            
        except Exception as e:
            print(f"数据加载失败: {e}")
            return False
        
        return True
    
    def preprocess_data(self):
        """数据预处理和特征工程"""
        print("\n开始数据预处理和特征工程...")
        
        # 使用最新月份的数据
        latest_month = self.customer_behavior['stat_month'].max()
        print(f"使用最新月份数据: {latest_month}")
        
        # 筛选最新月份数据
        latest_behavior = self.customer_behavior[
            self.customer_behavior['stat_month'] == latest_month
        ].copy()
        
        # 合并数据
        self.merged_data = pd.merge(
            self.customer_base, 
            latest_behavior, 
            on='customer_id', 
            how='inner'
        )
        
        print(f"合并后数据量: {self.merged_data.shape}")
        
        # 创建目标变量：资产是否达到100万+
        self.merged_data['target_100w_plus'] = (
            self.merged_data['total_assets'] >= 100
        ).astype(int)
        
        print("目标变量分布:")
        target_counts = self.merged_data['target_100w_plus'].value_counts()
        print(target_counts)
        
        # 检查数据分布
        print(f"\n资产分布统计:")
        print(f"最小资产: {self.merged_data['total_assets'].min():.2f}万")
        print(f"最大资产: {self.merged_data['total_assets'].max():.2f}万")
        print(f"平均资产: {self.merged_data['total_assets'].mean():.2f}万")
        print(f"中位数资产: {self.merged_data['total_assets'].median():.2f}万")
        
        # 如果所有样本都是同一类别，调整阈值
        if len(target_counts) == 1:
            print("\n警告: 所有样本都属于同一类别，调整阈值...")
            # 使用更高的阈值，比如150万
            threshold = 150
            self.merged_data['target_100w_plus'] = (
                self.merged_data['total_assets'] >= threshold
            ).astype(int)
            print(f"使用新阈值 {threshold}万，目标变量分布:")
            new_counts = self.merged_data['target_100w_plus'].value_counts()
            print(new_counts)
            
            # 如果还是只有一个类别，使用中位数作为阈值
            if len(new_counts) == 1:
                threshold = self.merged_data['total_assets'].median()
                self.merged_data['target_100w_plus'] = (
                    self.merged_data['total_assets'] >= threshold
                ).astype(int)
                print(f"使用中位数阈值 {threshold:.2f}万，目标变量分布:")
                print(self.merged_data['target_100w_plus'].value_counts())
        
        # 特征工程
        self.create_features()
        
        return True
    
    def create_features(self):
        """创建预测特征"""
        print("创建预测特征...")
        
        # 基础数值特征
        numeric_features = [
            'age', 'monthly_income', 'total_assets', 'deposit_balance',
            'financial_balance', 'fund_balance', 'insurance_balance',
            'product_count', 'financial_repurchase_count', 'credit_card_monthly_expense',
            'investment_monthly_count', 'app_login_count', 'app_financial_view_time',
            'app_product_compare_count'
        ]
        
        # 创建衍生特征
        self.merged_data['asset_income_ratio'] = (
            self.merged_data['total_assets'] / (self.merged_data['monthly_income'] + 1)
        )
        
        self.merged_data['financial_ratio'] = (
            self.merged_data['financial_balance'] / (self.merged_data['total_assets'] + 1)
        )
        
        self.merged_data['product_diversity'] = self.merged_data['product_count']
        
        # 类别特征编码
        categorical_features = [
            'gender', 'occupation_type', 'lifecycle_stage', 'marriage_status',
            'city_level', 'asset_level', 'contact_result'
        ]
        
        # 对类别特征进行标签编码
        label_encoders = {}
        for feature in categorical_features:
            if feature in self.merged_data.columns:
                le = LabelEncoder()
                self.merged_data[f'{feature}_encoded'] = le.fit_transform(
                    self.merged_data[feature].astype(str)
                )
                label_encoders[feature] = le
        
        # 创建年龄组和收入组
        self.merged_data['age_group'] = pd.cut(
            self.merged_data['age'], 
            bins=[0, 30, 40, 50, 100], 
            labels=['青年', '中年前期', '中年后期', '老年']
        )
        
        self.merged_data['income_group'] = pd.cut(
            self.merged_data['monthly_income'], 
            bins=[0, 10000, 20000, 50000, float('inf')], 
            labels=['低收入', '中等收入', '高收入', '超高收入']
        )
        
        # 对新创建的分组特征进行编码
        le_age = LabelEncoder()
        self.merged_data['age_group_encoded'] = le_age.fit_transform(
            self.merged_data['age_group'].astype(str)
        )
        
        le_income = LabelEncoder()
        self.merged_data['income_group_encoded'] = le_income.fit_transform(
            self.merged_data['income_group'].astype(str)
        )
        
        # 最终特征列表
        self.feature_names = (
            numeric_features + 
            ['asset_income_ratio', 'financial_ratio', 'product_diversity'] +
            [f'{f}_encoded' for f in categorical_features if f in self.merged_data.columns] +
            ['age_group_encoded', 'income_group_encoded']
        )
        
        # 确保所有特征都存在
        available_features = [f for f in self.feature_names if f in self.merged_data.columns]
        self.feature_names = available_features
        
        print(f"最终特征数量: {len(self.feature_names)}")
        print(f"特征列表: {self.feature_names}")
        
        # 处理缺失值
        for feature in self.feature_names:
            if self.merged_data[feature].isnull().sum() > 0:
                if self.merged_data[feature].dtype in ['int64', 'float64']:
                    self.merged_data[feature].fillna(
                        self.merged_data[feature].median(), inplace=True
                    )
                else:
                    self.merged_data[feature].fillna(0, inplace=True)
        
        # 准备特征和目标变量
        self.features = self.merged_data[self.feature_names]
        self.target = self.merged_data['target_100w_plus']
    
    def train_decision_tree(self):
        """训练决策树模型"""
        print("\n开始训练决策树模型...")
        
        # 划分训练集和测试集
        self.X_train, self.X_test, self.y_train, self.y_test = train_test_split(
            self.features, self.target, test_size=0.2, random_state=42, stratify=self.target
        )
        
        # 创建决策树模型 (深度=4)
        self.dt_model = DecisionTreeClassifier(
            max_depth=4,
            random_state=42,
            min_samples_split=20,
            min_samples_leaf=10,
            class_weight='balanced'
        )
        
        # 训练模型
        self.dt_model.fit(self.X_train, self.y_train)
        
        # 预测
        y_train_pred = self.dt_model.predict(self.X_train)
        y_test_pred = self.dt_model.predict(self.X_test)
        
        # 评估模型
        train_accuracy = accuracy_score(self.y_train, y_train_pred)
        test_accuracy = accuracy_score(self.y_test, y_test_pred)
        
        print(f"训练集准确率: {train_accuracy:.4f}")
        print(f"测试集准确率: {test_accuracy:.4f}")
        
        return True
    
    def generate_text_visualization(self):
        """生成决策树文本可视化"""
        print("\n生成决策树文本可视化...")
        
        # 检查类别数量
        n_classes = len(self.dt_model.classes_)
        print(f"模型类别数量: {n_classes}")
        print(f"类别: {self.dt_model.classes_}")
        
        # 根据类别数量设置class_names
        if n_classes == 1:
            # 只有一个类别的情况
            if self.dt_model.classes_[0] == 0:
                class_names = ['非100万+']
            else:
                class_names = ['100万+']
        else:
            class_names = ['非100万+', '100万+']
        
        # 生成决策树文本表示
        tree_text = export_text(
            self.dt_model,
            feature_names=self.feature_names,
            class_names=class_names,
            max_depth=4,
            spacing=3,
            decimals=2,
            show_weights=True
        )
        
        # 保存文本可视化
        with open('outputs/decision_tree_rules.txt', 'w', encoding='utf-8') as f:
            f.write("决策树规则 - 客户资产提升至100万+预测\n")
            f.write("=" * 60 + "\n\n")
            f.write("决策树结构:\n")
            f.write(tree_text)
            f.write("\n\n")
            
            # 添加特征说明
            f.write("特征说明:\n")
            f.write("-" * 30 + "\n")
            feature_descriptions = {
                'total_assets': '总资产',
                'deposit_balance': '存款余额',
                'financial_balance': '理财余额',
                'fund_balance': '基金余额',
                'insurance_balance': '保险余额',
                'monthly_income': '月收入',
                'age': '年龄',
                'asset_income_ratio': '资产收入比',
                'financial_ratio': '理财占比',
                'app_login_count': 'APP登录次数',
                'product_count': '产品数量',
                'investment_monthly_count': '投资月度次数'
            }
            
            for feature in self.feature_names:
                desc = feature_descriptions.get(feature, feature)
                f.write(f"{feature}: {desc}\n")
        
        print("决策树文本规则已保存到 outputs/decision_tree_rules.txt")
        
        # 在控制台打印主要决策路径
        print("\n主要决策路径:")
        print("-" * 40)
        print(tree_text[:2000])  # 打印前2000个字符
        if len(tree_text) > 2000:
            print("... (完整规则请查看 outputs/decision_tree_rules.txt)")
    
    def generate_graph_visualization(self):
        """生成决策树图形可视化"""
        print("\n创建决策树图形可视化...")
        
        # 检查类别数量并设置class_names
        n_classes = len(self.dt_model.classes_)
        if n_classes == 1:
            if self.dt_model.classes_[0] == 0:
                class_names = ['非100万+']
            else:
                class_names = ['100万+']
        else:
            class_names = ['非100万+', '100万+']
        
        # 创建图形
        plt.figure(figsize=(20, 12))
        
        # 绘制决策树
        plot_tree(
            self.dt_model,
            feature_names=self.feature_names,
            class_names=class_names,
            filled=True,
            rounded=True,
            fontsize=8,
            max_depth=4
        )
        
        plt.title('决策树可视化 - 客户资产提升至100万+预测', fontsize=16, pad=20)
        plt.tight_layout()
        
        # 保存图片
        plt.savefig('outputs/decision_tree_visualization.png', dpi=300, bbox_inches='tight')
        plt.savefig('outputs/decision_tree_visualization.svg', bbox_inches='tight')
        
        print("决策树图形可视化已保存到:")
        print("- outputs/decision_tree_visualization.png")
        print("- outputs/decision_tree_visualization.svg")
        
        plt.close()
    
    def analyze_feature_importance(self):
        """分析特征重要性"""
        print("\n分析特征重要性...")
        
        # 获取特征重要性
        feature_importance = pd.DataFrame({
            'feature': self.feature_names,
            'importance': self.dt_model.feature_importances_
        }).sort_values('importance', ascending=False)
        
        print("特征重要性排序:")
        print("-" * 40)
        for idx, row in feature_importance.head(10).iterrows():
            print(f"{row['feature']:<25}: {row['importance']:.4f}")
        
        # 保存特征重要性
        feature_importance.to_csv('outputs/decision_tree_feature_importance.csv', 
                                index=False, encoding='utf-8')
        
        # 创建特征重要性可视化
        plt.figure(figsize=(12, 8))
        top_features = feature_importance.head(15)
        
        bars = plt.barh(range(len(top_features)), top_features['importance'])
        plt.yticks(range(len(top_features)), top_features['feature'])
        plt.xlabel('特征重要性')
        plt.title('决策树特征重要性排序 (Top 15)')
        plt.gca().invert_yaxis()
        
        # 添加数值标签
        for i, bar in enumerate(bars):
            width = bar.get_width()
            plt.text(width + 0.001, bar.get_y() + bar.get_height()/2, 
                    f'{width:.3f}', ha='left', va='center')
        
        plt.tight_layout()
        plt.savefig('outputs/decision_tree_feature_importance.png', dpi=300, bbox_inches='tight')
        plt.savefig('outputs/decision_tree_feature_importance.svg', bbox_inches='tight')
        plt.close()
        
        print("特征重要性分析已保存到:")
        print("- outputs/decision_tree_feature_importance.csv")
        print("- outputs/decision_tree_feature_importance.png")
        
        return feature_importance
    
    def generate_classification_report(self):
        """生成分类报告"""
        print("\n生成分类报告...")
        
        # 预测
        y_pred = self.dt_model.predict(self.X_test)
        
        # 检查类别并设置target_names
        n_classes = len(self.dt_model.classes_)
        if n_classes == 1:
            if self.dt_model.classes_[0] == 0:
                target_names = ['非100万+']
            else:
                target_names = ['100万+']
        else:
            target_names = ['非100万+', '100万+']
        
        # 分类报告
        report = classification_report(
            self.y_test, y_pred, 
            target_names=target_names,
            output_dict=True
        )
        
        print("分类报告:")
        print(classification_report(self.y_test, y_pred, target_names=target_names))
        
        # 混淆矩阵
        cm = confusion_matrix(self.y_test, y_pred)
        
        # 设置混淆矩阵标签
        n_classes = len(self.dt_model.classes_)
        if n_classes == 1:
            if self.dt_model.classes_[0] == 0:
                labels = ['非100万+']
            else:
                labels = ['100万+']
        else:
            labels = ['非100万+', '100万+']
        
        # 可视化混淆矩阵
        plt.figure(figsize=(8, 6))
        sns.heatmap(cm, annot=True, fmt='d', cmap='Blues',
                   xticklabels=labels,
                   yticklabels=labels)
        plt.title('决策树预测混淆矩阵')
        plt.ylabel('实际标签')
        plt.xlabel('预测标签')
        plt.tight_layout()
        plt.savefig('outputs/decision_tree_confusion_matrix.png', dpi=300, bbox_inches='tight')
        plt.close()
        
        return report
    
    def extract_decision_paths(self):
        """提取关键决策路径"""
        print("\n提取关键决策路径...")
        
        # 获取决策树结构
        tree = self.dt_model.tree_
        
        def get_path_to_leaf(tree, node_id, path=[]):
            """递归获取到叶子节点的路径"""
            if tree.children_left[node_id] == tree.children_right[node_id]:
                # 叶子节点
                return [path]
            else:
                paths = []
                # 左子树
                left_path = path + [f"{self.feature_names[tree.feature[node_id]]} <= {tree.threshold[node_id]:.2f}"]
                paths.extend(get_path_to_leaf(tree, tree.children_left[node_id], left_path))
                
                # 右子树
                right_path = path + [f"{self.feature_names[tree.feature[node_id]]} > {tree.threshold[node_id]:.2f}"]
                paths.extend(get_path_to_leaf(tree, tree.children_right[node_id], right_path))
                
                return paths
        
        # 获取所有路径
        all_paths = get_path_to_leaf(tree, 0)
        
        # 保存决策路径
        with open('outputs/decision_tree_paths.txt', 'w', encoding='utf-8') as f:
            f.write("决策树关键路径分析\n")
            f.write("=" * 50 + "\n\n")
            
            for i, path in enumerate(all_paths):
                f.write(f"路径 {i+1}:\n")
                for step in path:
                    f.write(f"  → {step}\n")
                f.write("\n")
        
        print("决策路径已保存到 outputs/decision_tree_paths.txt")
    
    def run_analysis(self):
        """运行完整的决策树分析"""
        try:
            # 1. 加载数据
            if not self.load_data():
                return False
            
            # 2. 数据预处理
            if not self.preprocess_data():
                return False
            
            # 3. 训练决策树
            if not self.train_decision_tree():
                return False
            
            # 4. 生成文本可视化
            self.generate_text_visualization()
            
            # 5. 生成图形可视化
            self.generate_graph_visualization()
            
            # 6. 分析特征重要性
            feature_importance = self.analyze_feature_importance()
            
            # 7. 生成分类报告
            report = self.generate_classification_report()
            
            # 8. 提取决策路径
            self.extract_decision_paths()
            
            print("\n" + "=" * 60)
            print("决策树分析完成！")
            print("输出文件:")
            print("- outputs/decision_tree_rules.txt (文本规则)")
            print("- outputs/decision_tree_visualization.png (图形可视化)")
            print("- outputs/decision_tree_visualization.svg (矢量图)")
            print("- outputs/decision_tree_feature_importance.csv (特征重要性)")
            print("- outputs/decision_tree_feature_importance.png (重要性图)")
            print("- outputs/decision_tree_confusion_matrix.png (混淆矩阵)")
            print("- outputs/decision_tree_paths.txt (决策路径)")
            print("=" * 60)
            
            return True
            
        except Exception as e:
            print(f"分析过程中出现错误: {e}")
            import traceback
            traceback.print_exc()
            return False

if __name__ == "__main__":
    # 创建分析实例并运行
    analyzer = DecisionTreeAnalysis()
    analyzer.run_analysis()