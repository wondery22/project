# -*- coding: utf-8 -*-
"""
使用LightGBM预测客户未来3个月资产是否能提升至100万+
- 数据加载与合并（以最新月份为准：customer_behavior_assets.stat_month）
- 目标变量创建：total_assets >= 阈值（默认100万，若单一类别则动态调整）
- 特征工程：数值特征、行为特征、类别特征编码、缺失值处理
- 模型训练：LightGBM二分类（不进行特征归一化）
- 输出：
  * 特征重要性排序（文本打印、CSV保存）
  * 特征重要性可视化（SVG）
  * 分类报告（文本打印）
  * 混淆矩阵（SVG）
  * 预测结果样本（CSV）
"""

import os
import sys
import warnings
warnings.filterwarnings("ignore")

import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report, confusion_matrix
from sklearn.preprocessing import LabelEncoder
import matplotlib.pyplot as plt
import seaborn as sns

try:
    import lightgbm as lgb
except ImportError:
    print("未检测到lightgbm库，请先安装：pip install lightgbm")
    sys.exit(1)


class LightGBMAnalysis:
    def __init__(self,
                 base_path: str = '.',
                 base_file: str = 'customer_base.csv',
                 behavior_file: str = 'customer_behavior_assets.csv',
                 outputs_dir: str = 'outputs',
                 asset_threshold_default: float = 100.0,
                 random_state: int = 42):
        self.base_path = base_path
        self.base_file = os.path.join(base_path, base_file)
        self.behavior_file = os.path.join(base_path, behavior_file)
        self.outputs_dir = os.path.join(base_path, outputs_dir)
        os.makedirs(self.outputs_dir, exist_ok=True)
        self.asset_threshold_default = asset_threshold_default
        self.random_state = random_state

        self.base_df = None
        self.behavior_df = None
        self.merged_df = None

        self.feature_cols = []
        self.target_col = 'target_100w_plus'

        self.model = None
        self.X_train = None
        self.X_test = None
        self.y_train = None
        self.y_test = None
        self.customer_id_test = None

    # ------------------------
    # 数据加载与预处理
    # ------------------------
    def load_data(self):
        print("开始加载数据...")
        self.base_df = pd.read_csv(self.base_file, encoding='utf-8')
        self.behavior_df = pd.read_csv(self.behavior_file, encoding='utf-8')
        print(f"customer_base.csv 行列: {self.base_df.shape}")
        print(f"customer_behavior_assets.csv 行列: {self.behavior_df.shape}")

        # 选取最新月份数据（使用stat_month字段）
        if 'stat_month' in self.behavior_df.columns:
            latest_month = self.behavior_df['stat_month'].max()
            print(f"选取最新月份数据: {latest_month}")
            self.behavior_df = self.behavior_df[self.behavior_df['stat_month'] == latest_month].copy()
        else:
            print("未找到stat_month字段，默认使用全量行为资产数据进行合并")

        # 合并数据
        if 'customer_id' not in self.base_df.columns:
            raise KeyError('customer_base.csv 缺少 customer_id 字段')
        if 'customer_id' not in self.behavior_df.columns:
            raise KeyError('customer_behavior_assets.csv 缺少 customer_id 字段')

        self.merged_df = pd.merge(self.base_df, self.behavior_df, on='customer_id', how='inner')
        print(f"合并后数据量: {self.merged_df.shape}")

    def create_target(self):
        print("创建目标变量：资产是否达到100万+ ...")
        if 'total_assets' not in self.merged_df.columns:
            raise KeyError('缺少 total_assets 字段，无法创建目标变量')

        # 默认阈值100万
        threshold = self.asset_threshold_default
        self.merged_df[self.target_col] = (self.merged_df['total_assets'] >= threshold).astype(int)

        counts = self.merged_df[self.target_col].value_counts()
        print("目标变量分布:")
        print(counts)

        # 如果只有一个类别，则动态调整
        if len(counts) == 1:
            print("警告：目标变量只有一个类别，尝试提高阈值至150万...")
            threshold = 150.0
            self.merged_df[self.target_col] = (self.merged_df['total_assets'] >= threshold).astype(int)
            counts = self.merged_df[self.target_col].value_counts()
            print("新阈值分布:")
            print(counts)
            if len(counts) == 1:
                median_assets = float(self.merged_df['total_assets'].median())
                print(f"仍为单一类别，使用中位数阈值: {median_assets:.2f}万")
                self.merged_df[self.target_col] = (self.merged_df['total_assets'] >= median_assets).astype(int)
                counts = self.merged_df[self.target_col].value_counts()
                print("中位数阈值分布:")
                print(counts)

        print("资产分布统计:")
        print(f"最小资产: {self.merged_df['total_assets'].min():.2f}万")
        print(f"最大资产: {self.merged_df['total_assets'].max():.2f}万")
        print(f"平均资产: {self.merged_df['total_assets'].mean():.2f}万")
        print(f"中位数资产: {self.merged_df['total_assets'].median():.2f}万")

    def feature_engineering(self):
        print("开始特征工程...")
        df = self.merged_df.copy()

        # 数值型特征候选
        numeric_candidates = [
            'age', 'monthly_income', 'total_assets', 'deposit_balance', 'financial_balance',
            'fund_balance', 'insurance_balance', 'product_count', 'financial_repurchase_count',
            'credit_card_monthly_expense', 'investment_monthly_count', 'app_login_count',
            'app_financial_view_time', 'app_product_compare_count', 'asset_income_ratio',
            'financial_ratio', 'product_diversity'
        ]

        # 类别型特征候选
        categorical_candidates = [
            'gender', 'occupation_type', 'lifecycle_stage', 'marriage_status', 'city_level',
            'asset_level', 'contact_result'
        ]

        # 构造年龄分组与收入分组（如存在）
        if 'age' in df.columns:
            df['age_group'] = pd.cut(df['age'], bins=[0, 25, 35, 45, 60, 120], labels=[
                '≤25', '26-35', '36-45', '46-60', '>60'
            ], include_lowest=True)
            categorical_candidates.append('age_group')
        if 'monthly_income' in df.columns:
            df['income_group'] = pd.cut(df['monthly_income'], bins=[0, 5, 10, 20, 50, np.inf], labels=[
                '≤5k', '5-10k', '10-20k', '20-50k', '>50k'
            ], include_lowest=True)
            categorical_candidates.append('income_group')

        # 选择存在的特征列
        numeric_cols = [c for c in numeric_candidates if c in df.columns]
        categorical_cols = [c for c in categorical_candidates if c in df.columns]

        # 缺失值处理：数值型填充0，类别型填充缺失标签
        for c in numeric_cols:
            df[c] = pd.to_numeric(df[c], errors='coerce')
            df[c] = df[c].fillna(0)
        for c in categorical_cols:
            df[c] = df[c].astype(str).fillna('缺失')

        # 类别编码
        encoders = {}
        for c in categorical_cols:
            le = LabelEncoder()
            df[c] = le.fit_transform(df[c])
            encoders[c] = le

        self.feature_cols = numeric_cols + categorical_cols
        print(f"特征列数量: {len(self.feature_cols)}")
        print(f"特征列: {self.feature_cols}")

        # 保留customer_id用于输出预测样本
        if 'customer_id' not in df.columns:
            raise KeyError('缺少 customer_id 字段')

        return df

    # ------------------------
    # 模型训练与评估
    # ------------------------
    def train_model(self, df: pd.DataFrame):
        print("开始训练LightGBM模型（不进行特征归一化）...")
        X = df[self.feature_cols]
        y = df[self.target_col]
        customer_ids = df['customer_id']

        # 数据切分
        if len(y.unique()) < 2:
            raise ValueError("目标变量仍为单一类别，无法训练模型。请检查阈值与数据分布。")

        X_train, X_test, y_train, y_test, cid_train, cid_test = train_test_split(
            X, y, customer_ids, test_size=0.3, random_state=self.random_state, stratify=y
        )
        self.X_train, self.X_test = X_train, X_test
        self.y_train, self.y_test = y_train, y_test
        self.customer_id_test = cid_test

        # 模型定义
        self.model = lgb.LGBMClassifier(
            n_estimators=300,
            learning_rate=0.05,
            num_leaves=31,
            max_depth=-1,
            subsample=0.8,
            colsample_bytree=0.8,
            random_state=self.random_state,
            n_jobs=-1
        )

        # 训练
        self.model.fit(self.X_train, self.y_train)
        print("模型训练完成。")

    def print_and_save_feature_importance(self):
        print("分析特征重要性...")
        importances = self.model.feature_importances_
        fi_df = pd.DataFrame({
            'feature': self.feature_cols,
            'importance': importances
        }).sort_values('importance', ascending=False)

        # 文本打印
        print("特征重要性排序:")
        print("----------------------------------------")
        for _, row in fi_df.iterrows():
            print(f"{row['feature']:<30}: {row['importance']:.4f}")

        # 保存CSV
        fi_csv = os.path.join(self.outputs_dir, 'lgbm_feature_importance.csv')
        fi_df.to_csv(fi_csv, index=False, encoding='utf-8')
        print("特征重要性分析已保存到:")
        print(f"- {fi_csv}")

        # 可视化（SVG）
        plt.figure(figsize=(10, 6))
        sns.barplot(x='importance', y='feature', data=fi_df, palette='viridis')
        plt.title('LightGBM 特征重要性')
        plt.xlabel('重要性')
        plt.ylabel('特征')
        plt.tight_layout()
        fi_svg = os.path.join(self.outputs_dir, 'lgbm_feature_importance.svg')
        plt.savefig(fi_svg, format='svg')
        plt.close()
        print("特征重要性可视化已保存到:")
        print(f"- {fi_svg}")

    def classification_outputs(self):
        print("生成分类报告与混淆矩阵...")
        y_pred = self.model.predict(self.X_test)
        y_prob = self.model.predict_proba(self.X_test)[:, 1]

        # 分类报告（中文标签）
        classes = list(self.model.classes_)
        if len(classes) == 1:
            target_names = ['100万+'] if classes[0] == 1 else ['非100万+']
        else:
            # 确保顺序与模型类一致
            target_names = ['非100万+', '100万+'] if classes == [0, 1] else [str(c) for c in classes]

        report = classification_report(self.y_test, y_pred, target_names=target_names)
        print("分类报告:")
        print(report)

        # 混淆矩阵
        cm = confusion_matrix(self.y_test, y_pred)
        plt.figure(figsize=(7, 6))
        sns.heatmap(cm, annot=True, fmt='d', cmap='Blues',
                    xticklabels=target_names,
                    yticklabels=target_names)
        plt.title('LightGBM 预测混淆矩阵')
        plt.ylabel('实际标签')
        plt.xlabel('预测标签')
        plt.tight_layout()
        cm_svg = os.path.join(self.outputs_dir, 'lgbm_confusion_matrix.svg')
        plt.savefig(cm_svg, format='svg')
        plt.close()
        print("混淆矩阵已保存到:")
        print(f"- {cm_svg}")

        # 保存预测样本
        sample_df = pd.DataFrame({
            'customer_id': self.customer_id_test,
            'actual': self.y_test,
            'predicted': y_pred,
            'probability': y_prob
        })
        sample_df = sample_df.sample(n=min(200, len(sample_df)), random_state=self.random_state)
        sample_csv = os.path.join(self.outputs_dir, 'lgbm_predictions_sample.csv')
        sample_df.to_csv(sample_csv, index=False, encoding='utf-8')
        print("预测结果样本已保存到:")
        print(f"- {sample_csv}")

    def run(self):
        self.load_data()
        self.create_target()
        fe_df = self.feature_engineering()
        self.train_model(fe_df)
        self.print_and_save_feature_importance()
        self.classification_outputs()
        print("============================================================")
        print("LightGBM分析完成！输出文件:")
        print("- outputs/lgbm_feature_importance.csv")
        print("- outputs/lgbm_feature_importance.svg")
        print("- outputs/lgbm_confusion_matrix.svg")
        print("- outputs/lgbm_predictions_sample.csv")
        print("============================================================")


if __name__ == '__main__':
    analysis = LightGBMAnalysis(base_path='.')
    analysis.run()