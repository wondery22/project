# -*- coding: utf-8 -*-
"""
读取客户基础信息和客户行为资产数据的前5行
"""

import pandas as pd
import os

# 设置pandas显示选项，显示所有列
pd.set_option('display.max_columns', None)  # 显示所有列
pd.set_option('display.width', None)        # 不限制显示宽度
pd.set_option('display.max_colwidth', 20)   # 设置列宽度限制

def read_csv_first_5_rows():
    """
    读取customer_base.csv和customer_behavior_assets.csv的前5行数据
    """
    # 获取当前脚本所在目录
    current_dir = os.path.dirname(os.path.abspath(__file__))
    
    # 定义文件路径
    customer_base_file = os.path.join(current_dir, 'customer_base.csv')
    customer_behavior_file = os.path.join(current_dir, 'customer_behavior_assets.csv')
    
    print("=" * 80)
    print("读取CSV文件前5行数据")
    print("=" * 80)
    
    try:
        # 读取客户基础信息文件的前5行
        print("\n1. 客户基础信息 (customer_base.csv) - 前5行数据:")
        print("-" * 60)
        
        # 使用pandas读取CSV文件，只读取前5行数据
        customer_base_df = pd.read_csv(customer_base_file, nrows=5, encoding='utf-8')
        
        # 显示数据信息
        print(f"数据形状: {customer_base_df.shape}")
        print(f"列名: {list(customer_base_df.columns)}")
        print("\n数据内容:")
        # 使用to_string方法显示所有列
        print(customer_base_df.to_string(index=False, max_cols=None))
        
        print("\n" + "=" * 80)
        
        # 读取客户行为资产文件的前5行
        print("\n2. 客户行为资产信息 (customer_behavior_assets.csv) - 前5行数据:")
        print("-" * 60)
        
        # 使用pandas读取CSV文件，只读取前5行数据
        customer_behavior_df = pd.read_csv(customer_behavior_file, nrows=5, encoding='utf-8')
        
        # 显示数据信息
        print(f"数据形状: {customer_behavior_df.shape}")
        print(f"列名: {list(customer_behavior_df.columns)}")
        print("\n数据内容:")
        # 使用to_string方法显示所有列
        print(customer_behavior_df.to_string(index=False, max_cols=None))
        
        print("\n" + "=" * 80)
        print("数据读取完成！")
        
        return customer_base_df, customer_behavior_df
        
    except FileNotFoundError as e:
        print(f"错误：找不到文件 - {e}")
        return None, None
    except Exception as e:
        print(f"读取文件时发生错误: {e}")
        return None, None

def display_data_summary(customer_base_df, customer_behavior_df):
    """
    显示数据摘要信息
    """
    if customer_base_df is not None and customer_behavior_df is not None:
        print("\n数据摘要:")
        print("-" * 40)
        print(f"客户基础信息文件包含 {len(customer_base_df.columns)} 个字段")
        print(f"客户行为资产文件包含 {len(customer_behavior_df.columns)} 个字段")
        
        # 显示数据类型
        print("\n客户基础信息数据类型:")
        for col in customer_base_df.columns:
            print(f"  {col}: {customer_base_df[col].dtype}")
            
        print("\n客户行为资产数据类型:")
        for col in customer_behavior_df.columns:
            print(f"  {col}: {customer_behavior_df[col].dtype}")

if __name__ == "__main__":
    # 读取数据
    base_df, behavior_df = read_csv_first_5_rows()
    
    # 显示数据摘要
    display_data_summary(base_df, behavior_df)