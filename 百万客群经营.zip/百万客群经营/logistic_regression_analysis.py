# -*- coding: utf-8 -*-
"""
百万客群经营 - 逻辑回归预测分析
预测客户未来3个月资产提升至100万+的概率
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.metrics import classification_report, confusion_matrix, roc_auc_score, roc_curve
import warnings
warnings.filterwarnings('ignore')

# 设置中文字体
plt.rcParams['font.sans-serif'] = ['SimHei', 'Microsoft YaHei']
plt.rcParams['axes.unicode_minus'] = False

class LogisticRegressionAnalysis:
    def __init__(self):
        self.customer_base = None
        self.customer_behavior = None
        self.merged_data = None
        self.X_train = None
        self.X_test = None
        self.y_train = None
        self.y_test = None
        self.model = None
        self.scaler = None
        self.feature_names = None
        
    def load_data(self):
        """加载数据文件"""
        print("正在加载数据文件...")
        try:
            self.customer_base = pd.read_csv('customer_base.csv', encoding='utf-8')
            self.customer_behavior = pd.read_csv('customer_behavior_assets.csv', encoding='utf-8')
            print(f"客户基础信息表: {self.customer_base.shape}")
            print(f"客户行为资产表: {self.customer_behavior.shape}")
            return True
        except Exception as e:
            print(f"数据加载失败: {e}")
            return False
    
    def data_preprocessing(self):
        """数据预处理和特征工程"""
        print("\n开始数据预处理和特征工程...")
        
        # 获取最新月份的客户行为数据
        latest_month = self.customer_behavior['stat_month'].max()
        print(f"使用最新月份数据: {latest_month}")
        
        # 筛选最新月份数据
        current_data = self.customer_behavior[
            self.customer_behavior['stat_month'] == latest_month
        ].copy()
        
        # 合并客户基础信息
        self.merged_data = pd.merge(
            current_data, 
            self.customer_base, 
            on='customer_id', 
            how='inner'
        )
        
        print(f"合并后数据量: {self.merged_data.shape}")
        
        # 创建目标变量：未来3个月资产是否达到100万+
        # 这里我们基于当前资产水平和增长趋势来模拟未来资产
        self.merged_data['target_100w_plus'] = (
            self.merged_data['total_assets'] >= 1000000
        ).astype(int)
        
        # 如果当前没有100万+客户，我们基于资产水平创建一个合理的目标
        if self.merged_data['target_100w_plus'].sum() == 0:
            # 将资产前20%的客户标记为潜在100万+客户
            asset_threshold = self.merged_data['total_assets'].quantile(0.8)
            self.merged_data['target_100w_plus'] = (
                self.merged_data['total_assets'] >= asset_threshold
            ).astype(int)
        
        print(f"目标变量分布:")
        print(self.merged_data['target_100w_plus'].value_counts())
        
        # 特征工程
        self._create_features()
        
        return True
    
    def _create_features(self):
        """创建预测特征"""
        print("创建预测特征...")
        
        # 数值型特征
        numeric_features = [
            'age', 'monthly_income', 'total_assets', 'deposit_balance',
            'financial_balance', 'fund_balance', 'insurance_balance',
            'product_count', 'financial_repurchase_count', 
            'credit_card_monthly_expense', 'investment_monthly_count',
            'app_login_count', 'app_financial_view_time', 
            'app_product_compare_count'
        ]
        
        # 类别型特征编码
        categorical_features = [
            'gender', 'occupation_type', 'lifecycle_stage', 
            'marriage_status', 'city_level', 'asset_level',
            'contact_result'
        ]
        
        # 处理缺失值
        for col in numeric_features:
            if col in self.merged_data.columns:
                self.merged_data[col] = self.merged_data[col].fillna(
                    self.merged_data[col].median()
                )
        
        for col in categorical_features:
            if col in self.merged_data.columns:
                self.merged_data[col] = self.merged_data[col].fillna('未知')
        
        # 创建衍生特征
        self.merged_data['asset_income_ratio'] = (
            self.merged_data['total_assets'] / 
            (self.merged_data['monthly_income'] + 1)
        )
        
        self.merged_data['financial_ratio'] = (
            self.merged_data['financial_balance'] / 
            (self.merged_data['total_assets'] + 1)
        )
        
        self.merged_data['product_diversity'] = (
            self.merged_data['deposit_flag'] + 
            self.merged_data['financial_flag'] + 
            self.merged_data['fund_flag'] + 
            self.merged_data['insurance_flag']
        )
        
        # 年龄分组
        self.merged_data['age_group'] = pd.cut(
            self.merged_data['age'], 
            bins=[0, 30, 40, 50, 100], 
            labels=['青年', '中年', '中老年', '老年']
        )
        
        # 收入分组
        self.merged_data['income_group'] = pd.cut(
            self.merged_data['monthly_income'], 
            bins=[0, 20000, 40000, 60000, np.inf], 
            labels=['低收入', '中等收入', '高收入', '超高收入']
        )
        
        # 更新特征列表
        numeric_features.extend([
            'asset_income_ratio', 'financial_ratio', 'product_diversity'
        ])
        categorical_features.extend(['age_group', 'income_group'])
        
        # 对类别特征进行编码
        label_encoders = {}
        for col in categorical_features:
            if col in self.merged_data.columns:
                le = LabelEncoder()
                self.merged_data[f'{col}_encoded'] = le.fit_transform(
                    self.merged_data[col].astype(str)
                )
                label_encoders[col] = le
        
        # 选择最终特征
        encoded_categorical = [f'{col}_encoded' for col in categorical_features 
                             if col in self.merged_data.columns]
        
        self.feature_names = [col for col in numeric_features 
                            if col in self.merged_data.columns] + encoded_categorical
        
        print(f"最终特征数量: {len(self.feature_names)}")
        print("特征列表:", self.feature_names)
    
    def train_model(self):
        """训练逻辑回归模型"""
        print("\n开始训练逻辑回归模型...")
        
        # 准备特征和目标变量
        X = self.merged_data[self.feature_names].copy()
        y = self.merged_data['target_100w_plus'].copy()
        
        # 处理无穷大和NaN值
        X = X.replace([np.inf, -np.inf], np.nan)
        X = X.fillna(X.median())
        
        # 划分训练集和测试集
        self.X_train, self.X_test, self.y_train, self.y_test = train_test_split(
            X, y, test_size=0.2, random_state=42, stratify=y
        )
        
        # 特征标准化
        self.scaler = StandardScaler()
        self.X_train_scaled = self.scaler.fit_transform(self.X_train)
        self.X_test_scaled = self.scaler.transform(self.X_test)
        
        # 训练逻辑回归模型
        self.model = LogisticRegression(
            random_state=42,
            max_iter=1000,
            class_weight='balanced'  # 处理类别不平衡
        )
        
        self.model.fit(self.X_train_scaled, self.y_train)
        
        # 模型评估
        train_score = self.model.score(self.X_train_scaled, self.y_train)
        test_score = self.model.score(self.X_test_scaled, self.y_test)
        
        print(f"训练集准确率: {train_score:.4f}")
        print(f"测试集准确率: {test_score:.4f}")
        
        # 预测概率
        y_pred_proba = self.model.predict_proba(self.X_test_scaled)[:, 1]
        auc_score = roc_auc_score(self.y_test, y_pred_proba)
        print(f"AUC得分: {auc_score:.4f}")
        
        return True
    
    def get_coefficients(self):
        """获取逻辑回归系数"""
        if self.model is None:
            print("模型尚未训练!")
            return None
        
        # 获取系数
        coefficients = self.model.coef_[0]
        intercept = self.model.intercept_[0]
        
        # 创建系数DataFrame
        coeff_df = pd.DataFrame({
            'feature': self.feature_names,
            'coefficient': coefficients,
            'abs_coefficient': np.abs(coefficients)
        })
        
        # 按绝对值排序
        coeff_df = coeff_df.sort_values('abs_coefficient', ascending=False)
        
        print(f"\n逻辑回归截距: {intercept:.4f}")
        print("\n特征系数 (按重要性排序):")
        print(coeff_df.to_string(index=False))
        
        # 保存系数到CSV
        coeff_df.to_csv('outputs/logistic_coefficients.csv', 
                       index=False, encoding='utf-8-sig')
        print("\n系数已保存到 outputs/logistic_coefficients.csv")
        
        return coeff_df, intercept
    
    def visualize_coefficients(self, coeff_df):
        """可视化逻辑回归系数"""
        print("\n创建系数可视化图表...")
        
        # 创建图表
        plt.figure(figsize=(12, 8))
        
        # 选择前15个最重要的特征
        top_features = coeff_df.head(15).copy()
        
        # 创建颜色映射：正系数为绿色，负系数为红色
        colors = ['green' if x > 0 else 'red' for x in top_features['coefficient']]
        
        # 创建水平条形图
        bars = plt.barh(range(len(top_features)), 
                       top_features['coefficient'], 
                       color=colors, alpha=0.7)
        
        # 设置y轴标签
        plt.yticks(range(len(top_features)), top_features['feature'])
        
        # 添加数值标签
        for i, (bar, coeff) in enumerate(zip(bars, top_features['coefficient'])):
            plt.text(coeff + (0.01 if coeff > 0 else -0.01), i, 
                    f'{coeff:.3f}', 
                    va='center', ha='left' if coeff > 0 else 'right',
                    fontsize=9)
        
        # 添加垂直线在x=0处
        plt.axvline(x=0, color='black', linestyle='-', alpha=0.3)
        
        # 设置标题和标签
        plt.title('逻辑回归系数可视化\n预测客户未来3个月资产提升至100万+概率', 
                 fontsize=14, fontweight='bold', pad=20)
        plt.xlabel('系数值', fontsize=12)
        plt.ylabel('特征', fontsize=12)
        
        # 添加图例
        from matplotlib.patches import Patch
        legend_elements = [
            Patch(facecolor='green', alpha=0.7, label='正向影响 (增加概率)'),
            Patch(facecolor='red', alpha=0.7, label='负向影响 (降低概率)')
        ]
        plt.legend(handles=legend_elements, loc='lower right')
        
        # 调整布局
        plt.tight_layout()
        
        # 保存图表
        plt.savefig('outputs/logistic_coefficients.svg', 
                   dpi=300, bbox_inches='tight', format='svg')
        plt.savefig('outputs/logistic_coefficients.png', 
                   dpi=300, bbox_inches='tight')
        
        print("系数可视化图表已保存到 outputs/logistic_coefficients.svg")
        
        plt.show()
    
    def generate_predictions(self):
        """生成预测结果"""
        print("\n生成预测结果...")
        
        # 对测试集进行预测
        y_pred = self.model.predict(self.X_test_scaled)
        y_pred_proba = self.model.predict_proba(self.X_test_scaled)[:, 1]
        
        # 创建预测结果DataFrame
        predictions_df = pd.DataFrame({
            'actual': self.y_test,
            'predicted': y_pred,
            'probability': y_pred_proba
        })
        
        # 添加客户ID（如果可能）
        test_indices = self.X_test.index
        if 'customer_id' in self.merged_data.columns:
            predictions_df['customer_id'] = self.merged_data.loc[
                test_indices, 'customer_id'
            ].values
        
        # 保存预测结果样本
        sample_predictions = predictions_df.head(100)
        sample_predictions.to_csv('outputs/logistic_predictions_sample.csv', 
                                index=False, encoding='utf-8-sig')
        
        print("预测结果样本已保存到 outputs/logistic_predictions_sample.csv")
        
        # 打印分类报告
        print("\n分类报告:")
        print(classification_report(self.y_test, y_pred, 
                                  target_names=['非100万+', '100万+']))
        
        return predictions_df
    
    def run_analysis(self):
        """运行完整分析流程"""
        print("=" * 60)
        print("百万客群经营 - 逻辑回归预测分析")
        print("=" * 60)
        
        # 创建输出目录
        import os
        if not os.path.exists('outputs'):
            os.makedirs('outputs')
        
        # 执行分析步骤
        if not self.load_data():
            return False
        
        if not self.data_preprocessing():
            return False
        
        if not self.train_model():
            return False
        
        coeff_df, intercept = self.get_coefficients()
        if coeff_df is not None:
            self.visualize_coefficients(coeff_df)
        
        predictions_df = self.generate_predictions()
        
        print("\n" + "=" * 60)
        print("分析完成！")
        print("输出文件:")
        print("- outputs/logistic_coefficients.csv (系数数据)")
        print("- outputs/logistic_coefficients.svg (系数可视化)")
        print("- outputs/logistic_predictions_sample.csv (预测结果样本)")
        print("=" * 60)
        
        return True

if __name__ == "__main__":
    # 运行分析
    analyzer = LogisticRegressionAnalysis()
    analyzer.run_analysis()