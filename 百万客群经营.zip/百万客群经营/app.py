from flask import Flask, render_template, jsonify
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import os

app = Flask(__name__)

# 全局变量存储数据
customer_base_df = None
customer_behavior_df = None

def load_data():
    """加载CSV数据"""
    global customer_base_df, customer_behavior_df
    
    try:
        # 加载客户基础信息
        customer_base_df = pd.read_csv('customer_base.csv', encoding='utf-8')
        print(f"客户基础信息数据加载成功，共 {len(customer_base_df)} 条记录")
        
        # 加载客户行为资产数据
        customer_behavior_df = pd.read_csv('customer_behavior_assets.csv', encoding='utf-8')
        print(f"客户行为资产数据加载成功，共 {len(customer_behavior_df)} 条记录")
        
        return True
    except Exception as e:
        print(f"数据加载失败: {e}")
        return False

@app.route('/')
def dashboard():
    """主页面"""
    return render_template('dashboard.html')

@app.route('/api/customer-segmentation')
def customer_segmentation():
    """客户分层分布环形图API"""
    if customer_behavior_df is None or customer_base_df is None:
        return jsonify({'error': '数据未加载'}), 500
    
    try:
        # 获取最新月份的数据
        latest_month = customer_behavior_df['stat_month'].max()
        latest_data = customer_behavior_df[customer_behavior_df['stat_month'] == latest_month]
        
        # 计算资产等级分布
        asset_distribution = latest_data['asset_level'].value_counts()
        
        # 计算生命周期阶段分布
        lifecycle_distribution = customer_base_df['lifecycle_stage'].value_counts()
        
        # 计算职业类型分布
        occupation_distribution = customer_base_df['occupation_type'].value_counts()
        
        data = {
            'total_customers': len(latest_data),
            'asset_distribution': [
                {'name': level, 'value': int(count)} 
                for level, count in asset_distribution.items()
            ],
            'lifecycle_distribution': [
                {'name': stage, 'value': int(count)} 
                for stage, count in lifecycle_distribution.items()
            ],
            'occupation_distribution': [
                {'name': occupation, 'value': int(count)} 
                for occupation, count in occupation_distribution.items()
            ]
        }
        return jsonify(data)
    except Exception as e:
        print(f"客户分层计算错误: {e}")
        # 返回示例数据
        data = {
            'total_customers': 10000,
            'asset_distribution': [
                {'name': '50万以下', 'value': 3500},
                {'name': '50-100万', 'value': 2800},
                {'name': '100-300万', 'value': 2100},
                {'name': '300万以上', 'value': 1600}
            ],
            'lifecycle_distribution': [
                {'name': '新客户', 'value': 1200},
                {'name': '成长客户', 'value': 2800},
                {'name': '成熟客户', 'value': 3500},
                {'name': '忠诚客户', 'value': 2500}
            ],
            'occupation_distribution': [
                {'name': '专业人士', 'value': 3200},
                {'name': '企业高管', 'value': 2800},
                {'name': '事业单位', 'value': 2100},
                {'name': '传统行业', 'value': 1400},
                {'name': '互联网从业者', 'value': 500}
            ]
        }
        return jsonify(data)

@app.route('/api/asset-allocation')
def asset_allocation():
    """资产配置分析堆叠柱状图API"""
    if customer_behavior_df is None:
        return jsonify({'error': '数据未加载'}), 500
    
    try:
        # 获取最新月份的数据
        latest_month = customer_behavior_df['stat_month'].max()
        latest_data = customer_behavior_df[customer_behavior_df['stat_month'] == latest_month]
        
        # 按资产等级分组计算各类产品余额平均值
        asset_groups = latest_data.groupby('asset_level').agg({
            'deposit_balance': 'mean',
            'financial_balance': 'mean', 
            'fund_balance': 'mean',
            'insurance_balance': 'mean'
        }).round(2)
        
        # 转换为万元
        asset_groups = asset_groups / 10000
        
        categories = asset_groups.index.tolist()
        deposit_data = asset_groups['deposit_balance'].tolist()
        financial_data = asset_groups['financial_balance'].tolist()
        fund_data = asset_groups['fund_balance'].tolist()
        insurance_data = asset_groups['insurance_balance'].tolist()
        
        data = {
            'categories': categories,
            'deposit_data': deposit_data,
            'financial_data': financial_data,
            'fund_data': fund_data,
            'insurance_data': insurance_data
        }
        return jsonify(data)
    except Exception as e:
        print(f"资产配置计算错误: {e}")
        # 返回示例数据
        data = {
            'categories': ['50万以下', '50-100万', '100-300万', '300万以上'],
            'deposit_data': [15.2, 25.8, 45.6, 78.9],
            'financial_data': [8.5, 18.2, 35.4, 65.7],
            'fund_data': [5.8, 12.6, 28.9, 52.3],
            'insurance_data': [2.1, 4.8, 9.2, 18.5]
        }
        return jsonify(data)

@app.route('/api/lifecycle-funnel')
def lifecycle_funnel():
    """客户生命周期流转漏斗图API"""
    if customer_base_df is None:
        return jsonify({'error': '数据未加载'}), 500
    
    try:
        # 计算生命周期各阶段客户数量
        lifecycle_counts = customer_base_df['lifecycle_stage'].value_counts()
        
        # 按生命周期阶段排序
        stage_order = ['新客户', '成长客户', '成熟客户', '忠诚客户']
        funnel_data = []
        
        for stage in stage_order:
            if stage in lifecycle_counts.index:
                funnel_data.append({
                    'name': stage,
                    'value': int(lifecycle_counts[stage])
                })
        
        # 计算转化率
        total_customers = sum([item['value'] for item in funnel_data])
        for i, item in enumerate(funnel_data):
            if i == 0:
                item['conversion_rate'] = 100.0
            else:
                prev_value = funnel_data[i-1]['value']
                item['conversion_rate'] = round((item['value'] / prev_value) * 100, 1)
        
        data = {
            'funnel_data': funnel_data,
            'total_customers': total_customers
        }
        return jsonify(data)
    except Exception as e:
        print(f"生命周期漏斗计算错误: {e}")
        # 返回示例数据
        funnel_data = [
            {'name': '新客户', 'value': 1200, 'conversion_rate': 100.0},
            {'name': '成长客户', 'value': 2800, 'conversion_rate': 233.3},
            {'name': '成熟客户', 'value': 3500, 'conversion_rate': 125.0},
            {'name': '忠诚客户', 'value': 2500, 'conversion_rate': 71.4}
        ]
        data = {
            'funnel_data': funnel_data,
            'total_customers': 10000
        }
        return jsonify(data)

@app.route('/api/marketing-trends')
def marketing_trends():
    """营销效果趋势折线图API"""
    if customer_behavior_df is None:
        return jsonify({'error': '数据未加载'}), 500
    
    try:
        # 按月份统计营销效果指标
        monthly_stats = customer_behavior_df.groupby('stat_month').agg({
            'contact_result': lambda x: (x == '成功').sum() / len(x) * 100,  # 联系成功率
            'app_login_count': 'mean',  # 平均APP登录次数
            'financial_repurchase_count': 'mean'  # 平均复购次数
        }).round(2)
        
        months = monthly_stats.index.tolist()
        success_rates = monthly_stats['contact_result'].tolist()
        login_counts = monthly_stats['app_login_count'].tolist()
        repurchase_counts = monthly_stats['financial_repurchase_count'].tolist()
        
        data = {
            'months': months,
            'success_rates': success_rates,
            'login_counts': login_counts,
            'repurchase_counts': repurchase_counts
        }
        return jsonify(data)
    except Exception as e:
        print(f"营销趋势计算错误: {e}")
        # 返回示例数据
        data = {
            'months': ['2024-01', '2024-02', '2024-03', '2024-04', '2024-05', '2024-06'],
            'success_rates': [65.2, 68.5, 72.1, 75.8, 78.3, 81.2],
            'login_counts': [12.5, 14.2, 16.8, 18.9, 21.3, 23.7],
            'repurchase_counts': [2.1, 2.8, 3.2, 3.9, 4.5, 5.2]
        }
        return jsonify(data)

@app.route('/api/high-potential-customers')
def high_potential_customers():
    """高潜力客户识别散点图API"""
    if customer_behavior_df is None or customer_base_df is None:
        return jsonify({'error': '数据未加载'}), 500
    
    try:
        # 获取最新月份的数据
        latest_month = customer_behavior_df['stat_month'].max()
        latest_data = customer_behavior_df[customer_behavior_df['stat_month'] == latest_month]
        
        # 合并客户基础信息和行为数据
        merged_data = latest_data.merge(
            customer_base_df[['customer_id', 'monthly_income', 'occupation_type']], 
            on='customer_id', 
            how='left'
        )
        
        # 筛选高潜力客户（资产>50万且APP活跃度高）
        high_potential = merged_data[
            (merged_data['total_assets'] > 500000) & 
            (merged_data['app_login_count'] >= 5)
        ]
        
        # 生成散点图数据
        scatter_data = []
        for _, row in high_potential.head(200).iterrows():  # 限制显示200个点
            # 计算预测转化概率（基于资产、收入、APP活跃度的综合评分）
            asset_score = min(row['total_assets'] / 1000000, 5)  # 资产评分（最高5分）
            income_score = min(row['monthly_income'] / 50000, 3)  # 收入评分（最高3分）
            activity_score = min(row['app_login_count'] / 20, 2)  # 活跃度评分（最高2分）
            
            # 综合评分转换为转化概率
            total_score = asset_score + income_score + activity_score
            conversion_prob = min(total_score * 15, 95)  # 最高95%转化概率
            
            scatter_data.append([
                row['total_assets'] / 10000,  # X轴：资产规模（万元）
                conversion_prob,              # Y轴：预测转化概率
                row['app_login_count'],       # 散点大小：APP活跃度
                row['customer_id'],           # 客户ID
                row['occupation_type']        # 职业类型（用于颜色区分）
            ])
        
        data = {
            'scatter_data': scatter_data,
            'total_high_potential': len(high_potential),
            'avg_conversion_prob': round(sum([item[1] for item in scatter_data]) / len(scatter_data), 1) if scatter_data else 0
        }
        return jsonify(data)
    except Exception as e:
        print(f"高潜力客户计算错误: {e}")
        # 返回示例数据
        import random
        scatter_data = []
        for i in range(100):
            asset = random.randint(50, 800)
            conversion_prob = min(asset / 10 + random.randint(10, 50), 95)
            activity = random.randint(5, 25)
            scatter_data.append([
                asset,  # 资产（万元）
                conversion_prob,  # 转化概率
                activity,  # APP活跃度
                f'C{10000+i}',  # 客户ID
                random.choice(['专业人士', '企业高管', '事业单位', '传统行业', '互联网从业者'])  # 职业类型
            ])
        
        data = {
            'scatter_data': scatter_data,
            'total_high_potential': 1250,
            'avg_conversion_prob': 68.5
        }
        return jsonify(data)

if __name__ == '__main__':
    if load_data():
        print("启动可视化大屏服务...")
        print("访问地址: http://localhost:5000")
        app.run(debug=True, host='0.0.0.0', port=5000)
    else:
        print("数据加载失败，无法启动应用")